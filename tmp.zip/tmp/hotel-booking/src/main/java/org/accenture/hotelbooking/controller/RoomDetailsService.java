package org.accenture.hotelbooking.controller;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class RoomDetailsService {
	
	@Autowired
	private SeasonRepository seasonRepository;
	@Autowired
	private PeakSeasonRepository pickSeasonRepository;
	@Autowired
	private UnseasonRepository unseasonRepository;
	@Autowired
	private RoomRateTrendsRepository roomRateTrendsRepository;
	
	

	
	public List<RoomDetails> getRoomDetails() {
		List<RoomDetails> roomDetails = new ArrayList<>();
		seasonRepository.findAll()
		.forEach(roomDetails::add);
		return roomDetails;
	}
	
	
	  public List<UnseasonRoomDetails> getUnseasonRoomDetails() {
	  List<UnseasonRoomDetails> unseasonRoomDetails = new ArrayList<>();
	  unseasonRepository.findAll() 
	  .forEach(unseasonRoomDetails::add); 
	  return unseasonRoomDetails; 
	  }
	
	  public List<PeakseasonRoomDetails> getPickseansonRoomDetails() {
	  List<PeakseasonRoomDetails> pickseasonRoomDetails = new ArrayList<>();
	  pickSeasonRepository.findAll().
	  forEach(pickseasonRoomDetails::add); 
	  return pickseasonRoomDetails; }
	 
	
	public Optional<RoomDetails> getSeason(String room_type) {
	
		return seasonRepository.findById(room_type);
	}
	
	public Optional<UnseasonRoomDetails> getunseason(String room_type) {
		
		return unseasonRepository.findById(room_type);
	}
	
public Optional<PeakseasonRoomDetails> getpickseason(String room_type) {
		
		return pickSeasonRepository.findById(room_type);
	}

/*public List getyear(String roomType) {
	
	List findByyear = roomRateTrendsRepository.findByRate(roomType);
	return findByyear;
}*/

public List getType(String roomType) {
	List findByType = roomRateTrendsRepository.findByType(roomType);
	return findByType;
}

public List getTypeAndYear(String roomType, String year) {
	List findByType = roomRateTrendsRepository.findByTypeAndYear(roomType, year);
	return findByType;
}


//public Optional<RoomRateTrends> getyear(String roomtype, String year) {
	
	//Optional<RoomRateTrends> findByyear = roomRateTrendsRepository.findByRateAndYear(roomtype, year);
	//return findByyear;
}


	 
//return null;
	  
	  
