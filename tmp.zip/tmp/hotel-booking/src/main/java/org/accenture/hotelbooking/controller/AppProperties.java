package org.accenture.hotelbooking.controller;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("app")
public class AppProperties {
	
	private List jan;

	public List getJan() {
		return jan;
	}

	public void setJan(List jan) {
		this.jan = jan;
	}
	

}
