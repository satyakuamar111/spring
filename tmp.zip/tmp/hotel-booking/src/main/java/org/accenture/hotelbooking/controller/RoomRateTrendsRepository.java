package org.accenture.hotelbooking.controller;

import java.util.Collection;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface RoomRateTrendsRepository extends CrudRepository<RoomRateTrends, String>  {

	java.util.List findByRate(String roomtype);

	
	Optional<RoomRateTrends> findByRateAndYear(String roomtype, String year);
	
	java.util.List findByType(String roomType);
	java.util.List findByTypeAndYear(String roomType, String year);
}