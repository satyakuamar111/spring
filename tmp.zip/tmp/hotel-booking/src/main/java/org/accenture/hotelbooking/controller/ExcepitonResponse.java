package org.accenture.hotelbooking.controller;

public class ExcepitonResponse {
	
	
	private String error;

    public ExcepitonResponse() {

    }

    public ExcepitonResponse(String error) {
        this.error = error;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

}
