package org.accenture.hotelbooking.controller;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class DateNotFoundException  extends RuntimeException {
	  String  exception1 = "please enter a valid URL";
		  public DateNotFoundException(String exception) {
			  exception = exception1;
			
		  
		  }

		}

