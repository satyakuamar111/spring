package org.accenture.hotelbooking.controller;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


	@Entity
	@Table(name = "RoomRateTrends")
	public class RoomRateTrends {
		
		@Id
		@Column(name = "roomid")
		private String id;
		@Column(name = "roomdate")
		private String date;
		@Column(name = "roomrate")
		private int rate;
		@Column(name = "roomtype")
		private String type;
		@Column(name = "roomyear")
		private String year;
	
		public RoomRateTrends() {
			 
		}

		public RoomRateTrends(String id, String date, int rate, String type, String year) {
			super();
			this.id = id;
			this.date = date;
			this.rate = rate;
			this.type = type;
			this.year = year;
		}
		@JsonIgnore
		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getDate() {
			return date;
		}

		public void setDate(String date) {
			this.date = date;
		}

		public int getRate() {
			return rate;
		}

		public void setRate(int rate) {
			this.rate = rate;
		}
		@JsonIgnore
		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}
		@JsonIgnore
		public String getYear() {
			return year;
		}

		public void setYear(String year) {
			this.year = year;
		}
		
	
}
