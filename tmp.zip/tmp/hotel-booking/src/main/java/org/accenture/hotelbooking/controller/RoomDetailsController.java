package org.accenture.hotelbooking.controller;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RestController
public class RoomDetailsController {

	@Autowired
	private RoomDetailsService roomDetailsService;
	
	
	 

	@RequestMapping("/roomdetails/season")
	public List<RoomDetails> roomdetails() {
		
		

		return roomDetailsService.getRoomDetails();

	}

	
	  @RequestMapping("/roomdetails/unseason") 
	  public List<UnseasonRoomDetails> unseasonroomdetails() {
	  
	  return roomDetailsService.getUnseasonRoomDetails();
	 
	  }
	  
	  @RequestMapping("/roomdetails/peakseason") public List<PeakseasonRoomDetails>
	  peakseason() {
	  
	  return roomDetailsService.getPickseansonRoomDetails();
	  
	  
	  }
	 
	@RequestMapping("/roomdetails/unseason/{room_type}")
	public UnseasonRoomDetails getunseason(@PathVariable String room_type) {
		Optional<UnseasonRoomDetails> opttopic = roomDetailsService.getunseason(room_type);
		return opttopic.get();

	}
	
	@RequestMapping("/roomdetails/peakseason/{room_type}")
	public PeakseasonRoomDetails getpickseason(@PathVariable String room_type) {
		Optional<PeakseasonRoomDetails> opttopic = roomDetailsService.getpickseason(room_type);
		return opttopic.get();
	}
	
	@RequestMapping("/roomdetails/season/{room_type}")
	public RoomDetails getUser(@PathVariable String room_type) {
		Optional<RoomDetails> opttopic = roomDetailsService.getSeason(room_type);
		return opttopic.get();

	}
	

	/*
	 * @RequestMapping("/roomdetails/{roomtype}") public List
	 * getRoomRateTrendsyear(@PathVariable int roomtype) { List opttopic =
	 * roomDetailsService.getyear(roomtype);
	 * System.out.println("my query"+opttopic); return (List) opttopic;
	 * 
	 * }
	 */

	/*
	 * @RequestMapping("/roomRateTrends") public List
	 * getRoomRateTrendsTypeYear(@RequestParam("roomType") String roomType) { List
	 * opttopic = roomDetailsService.getType(roomType); return (List) opttopic; }
	 */
	
	@RequestMapping("/roomRateTrends")
	public List getRoomRateTrendsTypeYear(@RequestParam("roomType") String roomType, @RequestParam("year") String year) {
		List opttopic = roomDetailsService.getTypeAndYear(roomType, year);
		return (List) opttopic;
	}
	
	@Value("${jan}")
	private int jan;
	@Value("${feb}")
	private int feb;
	@Value("${mar}")
	private int mar;
	@Value("${apr}")
	private int apr;
	@Value("${may}")
	private int may;
	@Value("${jun}")
	private int jun;
	@Value("${jul}")
	private int jul;
	@Value("${aug}")
	private int aug;
	@Value("${sep}")
	private int sep;
	@Value("${oct}")
	private int oct;
	@Value("${nov}")
	private int nov;
	@Value("${dec}")
	private int dec;
	
	@RequestMapping(value="/roomdetails/season/")
	public @ResponseBody List getDate(@RequestParam("date") String Date) {
		 LocalDate localDate = LocalDate.parse(Date);
	        
	        if(localDate.getMonthValue()==1)   {
	        	
	        	
	        	if(jan==1) {
	        		return roomDetailsService.getRoomDetails();
	        				
	        	}
	        	if(jan==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(jan==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==2) {
	        	
	        	
	        	if(feb==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(feb==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(feb==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==3) {
	        	
	        	
	        	if(mar==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(mar==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(mar==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==4) {
	        	
	        	
	        	if(apr==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(apr==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(apr==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==5) {
	        	
	        	
	        	if(may==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(may==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(may==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==6) {
	        	
	        	
	        	if(jun==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(jun==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(jun==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==7) {
	        	
	        	
	        	if(jul==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(jul==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(jul==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==8) {
	        	
	        	
	        	if(aug==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(aug==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(aug==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==9) {
	        	
	        	
	        	if(sep==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(sep==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(sep==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==10) {
	        	
	        	
	        	if(oct==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(oct==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(oct==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==11) {
	        	
	        	
	        	if(nov==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(nov==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(nov==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        else if(localDate.getMonthValue()==12) {
	        	
	        	
	        	if(dec==1) {
	        		return roomDetailsService.getRoomDetails();
	        	}
	        	if(dec==2) {
	        		return roomDetailsService.getUnseasonRoomDetails();
	        	}
	        	if(dec==3) {
	        		return roomDetailsService.getPickseansonRoomDetails();
	        	
	        	}
	        }
	        return null;

	}

	

}