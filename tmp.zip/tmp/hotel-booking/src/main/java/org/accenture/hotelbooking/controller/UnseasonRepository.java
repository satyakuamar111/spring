package org.accenture.hotelbooking.controller;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UnseasonRepository extends CrudRepository<UnseasonRoomDetails, String>  {

}
