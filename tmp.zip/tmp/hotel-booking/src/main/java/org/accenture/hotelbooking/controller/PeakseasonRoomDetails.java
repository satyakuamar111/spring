package org.accenture.hotelbooking.controller;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PeakseasonRoomDetails")
public class PeakseasonRoomDetails {

	@Id
	@Column(name = "room_type")
	private String room_type;
	@Column(name = "room_rate")
	private String room_rate;
	
	public PeakseasonRoomDetails() {
		 
	}

	public PeakseasonRoomDetails(String room_type, String room_rate) {
		super();
		room_type = room_type;
		room_rate = room_rate;
	}

	public String getroom_type() {
		return room_type;
	}

	public void setroom_type(String room_type) {
		room_type = room_type;
	}

	public String getroom_rate() {
		return room_rate;
	}

	public void setroom_rate(String room_rate) {
		room_rate = room_rate;
	}
	
	
	
}
